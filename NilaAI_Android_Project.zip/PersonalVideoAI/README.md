# Nila AI — Personal Video AI Android Project

This is a build-ready Android Studio starter for a South Indian female personal video assistant.

Included:
- Tamil/Tanglish-first UI
- South Indian female assistant persona ("Nila")
- Video picker
- Tamil voice input
- Personal chat UI
- Material Android structure

Important:
The actual AI video understanding / voice synthesis requires an AI backend/API key. This project intentionally does not contain a secret API key. Connect your chosen AI provider in MainActivity/backend before production use.

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).

The resulting debug APK will normally be under:
app/build/outputs/apk/debug/app-debug.apk
