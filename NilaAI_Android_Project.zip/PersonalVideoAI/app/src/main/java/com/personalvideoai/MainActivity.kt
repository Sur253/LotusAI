package com.personalvideoai

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.*
import android.graphics.Color
import android.view.ViewGroup

class MainActivity : Activity() {
    private lateinit var chat: LinearLayout
    private val purple = Color.rgb(116, 76, 180)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 20)
            setBackgroundColor(Color.rgb(20, 17, 28))
        }

        val title = TextView(this).apply {
            text = "Nila AI  ✨"
            textSize = 28f
            setTextColor(Color.WHITE)
            setPadding(0, 8, 0, 4)
        }
        root.addView(title)

        val subtitle = TextView(this).apply {
            text = "உங்கள் personal South Indian AI video assistant"
            textSize = 15f
            setTextColor(Color.LTGRAY)
        }
        root.addView(subtitle)

        val avatar = TextView(this).apply {
            text = "👩🏽‍💻\n\nவணக்கம்! நான் Nila.\nVideo-வை upload பண்ணுங்க; அதைப் புரிந்து கொண்டு உங்களோடு Tamil / Tanglish-ல பேசுவேன்."
            textSize = 18f
            gravity = 17
            setTextColor(Color.WHITE)
            setPadding(24, 36, 24, 36)
            setBackgroundColor(Color.rgb(48, 40, 62))
        }
        val avp = LinearLayout.LayoutParams(-1, 0, 1f)
        avp.setMargins(0, 24, 0, 18)
        root.addView(avatar, avp)

        val buttons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val upload = Button(this).apply {
            text = "🎥  Video"
            setOnClickListener { chooseVideo() }
        }
        val voice = Button(this).apply {
            text = "🎙️  பேசு"
            setOnClickListener { startVoice() }
        }
        buttons.addView(upload, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(voice, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(buttons)

        val input = EditText(this).apply {
            hint = "Nila-விடம் கேளுங்கள்..."
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setSingleLine(false)
        }
        root.addView(input)

        val send = Button(this).apply {
            text = "Send"
            setOnClickListener {
                val q = input.text.toString().trim()
                if (q.isNotEmpty()) {
                    Toast.makeText(this@MainActivity, "Nila AI: Backend/API இணைக்கப்பட்டதும் பதில் வரும் — “$q”", Toast.LENGTH_LONG).show()
                    input.text.clear()
                }
            }
        }
        root.addView(send)

        setContentView(root)
    }

    private fun chooseVideo() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "video/*"
            addCategory(Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(i, 10)
    }

    private fun startVoice() {
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ta-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Nila-விடம் பேசுங்கள்")
        }
        try { startActivityForResult(i, 20) }
        catch (_: Exception) {
            Toast.makeText(this, "Voice input இந்த device-ல் கிடைக்கவில்லை.", Toast.LENGTH_SHORT).show()
        }
    }
}
